 <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!-- User details -->
                

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title">Menu</li>

                            <li>
                                <a href="<?php echo e(url('/dashboard')); ?>" class="waves-effect">
                                    <i class="ri-home-fill"></i> 
                                    <span>Dashboard</span>
                                </a>
                            </li>
 
                
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-hotel-fill"></i>
                <span>Manage Suppliers</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('supplier.all')); ?>">All Supplier</a></li>
               
            </ul>
        </li>


        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-shield-user-fill"></i>
                <span>Manage Customers</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('customer.all')); ?>">All Customers</a></li>
                 <li><a href="<?php echo e(route('credit.customer')); ?>">Credit Customers</a></li>

                 <li><a href="<?php echo e(route('paid.customer')); ?>">Paid Customers</a></li>
                  <li><a href="<?php echo e(route('customer.wise.report')); ?>">Customer Wise Report</a></li>
               
            </ul>
        </li>


         <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-delete-back-fill"></i>
                <span>Manage Units</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('unit.all')); ?>">All Unit</a></li>
               
            </ul>
        </li>

         <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-apps-2-fill"></i>
                <span>Manage Category</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('category.all')); ?>">All Category</a></li>
               
            </ul>
        </li>


          <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-reddit-fill"></i>
                <span>Manage Product</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('product.all')); ?>">All Product</a></li>
               
            </ul>
        </li>


          <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-oil-fill"></i>
                <span>Manage Purchase</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('purchase.all')); ?>">All Purchase</a></li>
                <li><a href="<?php echo e(route('purchase.pending')); ?>">Approval Purchase</a></li>
                <li><a href="<?php echo e(route('daily.purchase.report')); ?>">Daily Purchase Report</a></li>
               
            </ul>
        </li>


          <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-compass-2-fill"></i>
                <span>Manage Invoice</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('invoice.all')); ?>">All Invoice</a></li>
                <li><a href="<?php echo e(route('invoice.pending.list')); ?>">Approval Invoice</a></li>
                <li><a href="<?php echo e(route('print.invoice.list')); ?>">Print Invoice List</a></li>
                  <li><a href="<?php echo e(route('daily.invoice.report')); ?>">Daily Invoice Report</a></li>
               
            </ul>
        </li>

                             





                            <li class="menu-title">Stock</li>

    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="ri-gift-fill"></i>
            <span>Manage Stock</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('stock.report')); ?>">Stock Report</a></li>
            <li><a href="<?php echo e(route('stock.supplier.wise')); ?>">Supplier / Product Wise </a></li>
            
        </ul>
    </li>

                            <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <i class="ri-profile-line"></i>
                                    <span>Support</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="pages-starter.html">Starter Page</a></li>
                                    <li><a href="pages-timeline.html">Timeline</a></li>
                                    <li><a href="pages-directory.html">Directory</a></li>
                                    <li><a href="pages-invoice.html">Invoice</a></li>
                                    <li><a href="pages-404.html">Error 404</a></li>
                                    <li><a href="pages-500.html">Error 500</a></li>
                                </ul>
                            </li>

                           

                            
                         

                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div><?php /**PATH E:\xampp\htdocs\Laravel Projects\inventory-management-system-master\resources\views/admin/body/sidebar.blade.php ENDPATH**/ ?>