<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                 AQAB © aqab@gmail.com.com.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Crafted with <i class="mdi mdi-heart text-danger"></i> by AQAB
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
<?php /**PATH E:\xampp\htdocs\Laravel Projects\AQABSOFTWARE\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>