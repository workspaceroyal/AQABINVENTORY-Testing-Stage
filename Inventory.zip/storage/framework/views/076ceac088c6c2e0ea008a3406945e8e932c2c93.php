 <div class="vertical-menu">

    <div data-simplebar class="h-100">

                    <!-- User details -->
        <?php
        $id = Auth::user()->id;
        $adminData = App\Models\User::find($id);
        ?>


        <div class="mt-3 text-center user-profile">

            <a href="<?php echo e(route('admin.profile')); ?>">

                <div>
                    <img class="avatar-md rounded-circle" src="<?php echo e((!empty($adminData->profile_image))? url('upload/admin_images/'.$adminData->profile_image):url('upload/no_image.jpg')); ?>"
                    alt="Header Avatar">
                </div>

                <div class="mt-3">
                    <h4 class="mb-1 font-size-16"><?php echo e($adminData->name); ?></h4>
                    <span class="text-muted"><i class="align-middle ri-record-circle-line font-size-14 text-success"></i> Online</span>
                </div>
        </a>
        </div>


                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title">Menu</li>

                            <li>
                                <a href="<?php echo e(url('/dashboard')); ?>" class="waves-effect">
                                    <i class="ri-home-fill"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>


        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-hotel-fill"></i>
                <span>Suppliers</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('supplier.all')); ?>">All Supplier</a></li>

            </ul>
        </li>


        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-shield-user-fill"></i>
                <span>Customers</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('customer.all')); ?>">All Customers</a></li>
                 <li><a href="<?php echo e(route('credit.customer')); ?>">Credit Customers</a></li>

                 <li><a href="<?php echo e(route('paid.customer')); ?>">Paid Customers</a></li>
                  <li><a href="<?php echo e(route('customer.wise.report')); ?>">Customer Wise Report</a></li>

            </ul>
        </li>


         <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-delete-back-fill"></i>
                <span>Units</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('unit.all')); ?>">All Unit</a></li>

            </ul>
        </li>

         <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-apps-2-fill"></i>
                <span>Category</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('category.all')); ?>">All Category</a></li>

            </ul>
        </li>


          <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-reddit-fill"></i>
                <span>Product</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('product.all')); ?>">All Product</a></li>

            </ul>
        </li>


          <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-oil-fill"></i>
                <span>Purchase</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('purchase.all')); ?>">All Purchase</a></li>
                <li><a href="<?php echo e(route('purchase.pending')); ?>">Approval Purchase</a></li>
                <li><a href="<?php echo e(route('daily.purchase.report')); ?>">Daily Purchase Report</a></li>

            </ul>
        </li>


          <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ri-compass-2-fill"></i>
                <span>Invoice</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('invoice.all')); ?>">All Invoice</a></li>
                <li><a href="<?php echo e(route('invoice.pending.list')); ?>">Approval Invoice</a></li>
                <li><a href="<?php echo e(route('print.invoice.list')); ?>">Print Invoice List</a></li>
                  <li><a href="<?php echo e(route('daily.invoice.report')); ?>">Daily Invoice Report</a></li>

            </ul>
        </li>







                            <li class="menu-title">Stock</li>

    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="ri-gift-fill"></i>
            <span>Stock</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('stock.report')); ?>">Stock Report</a></li>
            <li><a href="<?php echo e(route('stock.supplier.wise')); ?>">Supplier / Product Wise </a></li>

        </ul>
    </li>

                            






                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
<?php /**PATH E:\xampp\htdocs\Laravel Projects\AQABSOFT\resources\views/admin/body/sidebar.blade.php ENDPATH**/ ?>